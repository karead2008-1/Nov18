# Car Physics Lab

A 3D car physics simulator in a single file: open `index.html` in a browser.

Adjust **mass, engine force, friction, slope, gravity, braking force, starting velocity** and the
brake point, press **Run**, and watch the car on a 3D test track with live force arrows.
Telemetry charts show **distance → velocity → acceleration → energy**, with the previous run
overlaid as a dashed ghost line. An energy ledger checks that
`start KE + engine work = KE + PE + heat` at every moment.

Challenges: 100 m Sprint, Speed Trap (hit 25 m/s at 100 m), Stop on the Line, Hill Climb.

Controls: `Enter` run/pause · `R` reset · hold `Space` to brake · drag the view to orbit, scroll to zoom.
